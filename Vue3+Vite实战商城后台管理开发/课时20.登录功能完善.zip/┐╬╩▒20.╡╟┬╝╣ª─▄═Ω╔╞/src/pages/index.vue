<template>
    <div>
        后台首页 
        
        {{ $store.state.user }}
    </div>
</template>
<script setup>
    
</script>